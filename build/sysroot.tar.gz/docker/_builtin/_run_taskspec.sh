#!/usr/bin/env sh
set -eu
cd /checkout
python3 ./gup.py
