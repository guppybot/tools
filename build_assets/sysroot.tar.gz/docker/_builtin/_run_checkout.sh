#!/usr/bin/env sh
set -eu
git clone -q --recursive ${GUPPY_GIT_REMOTE_URL} /checkout
