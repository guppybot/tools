#!/usr/bin/env sh
set -eu
python3 /gup.py
